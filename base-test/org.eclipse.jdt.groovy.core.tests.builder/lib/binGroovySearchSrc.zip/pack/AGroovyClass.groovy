package pack

class OtherClass { }
class AGroovyClass {
	String name_1
	int age_1
	def referencedInInitializer() { }
	def fieldInInitializer

	def doit() {
		println name_1 + age_1
		AGroovyClass
		OtherClass
		doit()
		def aClosure = {
			println name_1 + age_1
			AGroovyClass
			OtherClass
			doit()
		}
	}
	{ 
		referencedInInitializer() 
		fieldInInitializer
	}
}
