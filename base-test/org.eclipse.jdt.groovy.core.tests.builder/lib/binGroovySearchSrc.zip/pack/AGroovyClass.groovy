package pack

class OtherClass { }
class AGroovyClass {
	String name
	int age
	def referencedInInitializer() { }
	def fieldInInitializer

	def doit() {
		println name + age
		AGroovyClass
		OtherClass
		doit()
		def aClosure = {
			println name + age
			AGroovyClass
			OtherClass
			doit()
		}
	}
	{ 
		referencedInInitializer() 
		fieldInInitializer
	}
}
