package pack

class AnotherGroovyClass {
	def doit() {
		println new AGroovyClass().name + new AGroovyClass().age
		AGroovyClass
		OtherClass
		new AGroovyClass().doit()
		def aClosure = {
			println new AGroovyClass().name + new AGroovyClass().age
			AGroovyClass
			OtherClass
			new AGroovyClass().doit()
		}
	}
	{ 
		new AGroovyClass().referencedInInitializer() 
		new AGroovyClass().fieldInInitializer
	}
}
