package pack

class AnotherGroovyClass {
	def doit() {
		println new AGroovyClass().name_1 + new AGroovyClass().age_1
		AGroovyClass
		OtherClass
		new AGroovyClass().doit()
		def aClosure = {
			println new AGroovyClass().name_1 + new AGroovyClass().age_1
			AGroovyClass
			OtherClass
			new AGroovyClass().doit()
		}
	}
	{ 
		new AGroovyClass().referencedInInitializer() 
		new AGroovyClass().fieldInInitializer
	}
}
