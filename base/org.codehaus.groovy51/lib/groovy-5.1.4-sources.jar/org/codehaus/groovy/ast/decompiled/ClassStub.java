/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.codehaus.groovy.ast.decompiled;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Data structures holding class info to enable lazy loading
 */
public class ClassStub extends MemberStub {
    final String className;
    final int accessModifiers;
    final String signature;
    final String superName;
    final String[] interfaceNames;
    List<MethodStub> methods;
    List<FieldStub> fields;
    final List<String> permittedSubclasses = new ArrayList<>(1);
    final List<RecordComponentStub> recordComponents  = new ArrayList<>(1);

    // Used to store the real access modifiers for inner classes
    int innerClassModifiers = -1;

    /**
     * The INNERCLASS entries of a member class and of its enclosing member classes, outermost
     * first, as recorded in the class file. {@code null} for a top-level, local or anonymous class.
     */
    List<InnerClassStub> innerClassEntries;

    public ClassStub(String className, int accessModifiers, String signature, String superName, String[] interfaceNames) {
        this.className = className;
        this.accessModifiers = accessModifiers;
        this.signature = signature;
        this.superName = superName;
        this.interfaceNames = interfaceNames;
    }
}

interface AnnotatedStub {
    List<AnnotationStub> getAnnotations();
}

interface AnnotatedTypeStub {
    List<TypeAnnotationStub> getTypeAnnotations();
}

class MemberStub implements AnnotatedStub {
    List<AnnotationStub> annotations = null;

    AnnotationStub addAnnotation(String desc) {
        AnnotationStub stub = new AnnotationStub(desc);
        if (annotations == null) annotations = new ArrayList<AnnotationStub>(1);
        annotations.add(stub);
        return stub;
    }

    @Override
    public List<AnnotationStub> getAnnotations() {
        return annotations;
    }
}

class MethodStub extends MemberStub {
    final String methodName;
    final int accessModifiers;
    final String desc;
    final String signature;
    final String[] exceptions;
    Map<Integer, List<AnnotationStub>> parameterAnnotations;
    List<String> parameterNames;
    Object annotationDefault;

    public MethodStub(String methodName, int accessModifiers, String desc, String signature, String[] exceptions) {
        this.methodName = methodName;
        this.accessModifiers = accessModifiers;
        this.desc = desc;
        this.signature = signature;
        this.exceptions = exceptions;
    }
}

class FieldStub extends MemberStub {
    final String fieldName;
    final int accessModifiers;
    final String desc;
    final String signature;
    final Object value;

    public FieldStub(String fieldName, int accessModifiers, String desc, String signature) {
        this(fieldName, accessModifiers, desc, signature, null);
    }

    public FieldStub(String fieldName, int accessModifiers, String desc, String signature, Object value) {
        this.fieldName = fieldName;
        this.accessModifiers = accessModifiers;
        this.desc = desc;
        this.signature = signature;
        this.value = value;
    }
}

class AnnotationStub {
    final String className;
    final Map<String, Object> members = new LinkedHashMap<>();

    public AnnotationStub(String className) {
        this.className = className;
    }
}

class TypeAnnotationStub extends AnnotationStub {
    public TypeAnnotationStub(String className) {
        super(className);
    }
}

class TypeWrapper {
    final String desc;

    public TypeWrapper(String desc) {
        this.desc = desc;
    }
}

class EnumConstantWrapper {
    final String enumDesc;
    final String constant;

    public EnumConstantWrapper(String enumDesc, String constant) {
        this.enumDesc = enumDesc;
        this.constant = constant;
    }
}

class RecordComponentStub implements AnnotatedStub, AnnotatedTypeStub {
    final String name;
    final String descriptor;
    final String signature;
    List<AnnotationStub> annotations;
    List<TypeAnnotationStub> typeAnnotations;

    public RecordComponentStub(String name, String descriptor, String signature) {
        this.name = name;
        this.descriptor = descriptor;
        this.signature = signature;
    }

    AnnotationStub addAnnotation(String desc) {
        AnnotationStub stub = new AnnotationStub(desc);
        if (annotations == null) annotations = new ArrayList<AnnotationStub>(1);
        annotations.add(stub);
        return stub;
    }

    @Override
    public List<AnnotationStub> getAnnotations() {
        return annotations;
    }

    public TypeAnnotationStub addTypeAnnotation(String desc) {
        TypeAnnotationStub stub = new TypeAnnotationStub(desc);
        if (typeAnnotations == null) typeAnnotations = new ArrayList<TypeAnnotationStub>(1);
        typeAnnotations.add(stub);
        return stub;
    }

    @Override
    public List<TypeAnnotationStub> getTypeAnnotations() {
        return typeAnnotations;
    }
}

/**
 * Bytecode stub for an INNERCLASS entry (JVMS 4.7.6) of a member class.
 */
final class InnerClassStub {
    private final String name;
    private final String outerName;
    private final String innerName;
    private final int access;

    /**
     * @param name the internal name of the member class
     * @param outerName the internal name of the enclosing class
     * @param innerName the simple name of the member class
     * @param access the access flags of the member class
     */
    InnerClassStub(String name, String outerName, String innerName, int access) {
        this.name = name;
        this.outerName = outerName;
        this.innerName = innerName;
        this.access = access;
    }

    String name() {
        return name;
    }

    String outerName() {
        return outerName;
    }

    String innerName() {
        return innerName;
    }

    int access() {
        return access;
    }
}
