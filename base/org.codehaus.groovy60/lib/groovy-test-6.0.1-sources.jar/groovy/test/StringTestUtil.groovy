/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.test

/**
 * Utility methods for string-oriented assertions used by test support code.
 */
class StringTestUtil {
    /**
     * Asserts that two multi-line strings match after trimming and normalizing line endings.
     *
     * @param a the expected string
     * @param b the actual string
     */
    static void assertMultilineStringsEqual(String a, String b) {
        def aLines = a.trim().replaceAll('\r','').split('\n')
        def bLines = b.trim().replaceAll('\r','').split('\n')
        assert aLines.size() == bLines.size()
        for (i in 0..<aLines.size()) {
            assert aLines[i].trim() == bLines[i].trim()
        }
    }
}
