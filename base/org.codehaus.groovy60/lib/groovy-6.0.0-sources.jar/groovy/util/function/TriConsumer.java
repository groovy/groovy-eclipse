/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.util.function;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * A {@link Consumer Consumer} of three input arguments —
 * the three-argument cousin of {@link BiConsumer BiConsumer}
 * that {@code java.util.function} itself does not provide.
 *
 * @param <A> the first argument type
 * @param <B> the second argument type
 * @param <C> the third argument type
 * @since 6.0.0
 */
@FunctionalInterface
public interface TriConsumer<A, B, C> {

    /**
     * Performs the operation on the given arguments.
     */
    void accept(A a, B b, C c);
}
