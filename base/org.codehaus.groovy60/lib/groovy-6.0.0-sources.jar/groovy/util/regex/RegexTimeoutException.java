/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.util.regex;

import org.apache.groovy.lang.annotation.Incubating;

import java.io.Serial;

/**
 * Thrown when a regular expression evaluation guarded by {@link RegexGuard}
 * exceeds its configured deadline. Being unchecked, it distinguishes a
 * timed-out evaluation (which says nothing about whether the input matches)
 * from an ordinary non-match result.
 *
 * @see RegexGuard
 * @since 6.0.0
 */
@Incubating
public class RegexTimeoutException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 5023185918011980029L;

    public RegexTimeoutException(String message) {
        super(message);
    }
}
