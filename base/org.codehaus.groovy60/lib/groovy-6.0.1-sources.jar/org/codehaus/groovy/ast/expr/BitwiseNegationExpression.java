/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.codehaus.groovy.ast.expr;

import org.codehaus.groovy.ast.ClassHelper;
import org.codehaus.groovy.ast.ClassNode;
import org.codehaus.groovy.ast.GroovyCodeVisitor;

/**
 * Bitwise negation, written {@code ~(expression)}. A {@code String} or GString operand is
 * reported by {@link #getType()} as {@code Pattern}.
 */
public class BitwiseNegationExpression extends Expression {

    private final Expression expression;

    /**
     * Creates the negation of {@code expression}.
     *
     * @param expression the operand of {@code ~}
     */
    public BitwiseNegationExpression(final Expression expression) {
        this.expression = expression;
    }

    /**
     * Returns the operand of {@code ~}.
     *
     * @return the negated expression
     */
    public Expression getExpression() {
        return expression;
    }

    @Override
    public String getText() {
        return "~(" + getExpression().getText() + ")";
    }

    /**
     * @see org.codehaus.groovy.runtime.InvokerHelper#bitwiseNegate(Object)
     */
    @Override
    public ClassNode getType() {
        ClassNode type = getExpression().getType();
        if (ClassHelper.isStringType(type) || ClassHelper.isGStringType(type)) {
            type = ClassHelper.PATTERN_TYPE; // GROOVY-10936
        }
        return type;
    }

    @Override
    public Expression transformExpression(final ExpressionTransformer transformer) {
        Expression ret = new BitwiseNegationExpression(transformer.transform(getExpression()));
        ret.setSourcePosition(this);
        ret.copyNodeMetaData(this);
        return ret;
    }

    @Override
    public void visit(final GroovyCodeVisitor visitor) {
        visitor.visitBitwiseNegationExpression(this);
    }
}
