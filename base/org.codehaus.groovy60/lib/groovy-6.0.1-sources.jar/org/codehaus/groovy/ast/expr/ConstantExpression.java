/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.codehaus.groovy.ast.expr;

import org.codehaus.groovy.ast.ClassHelper;
import org.codehaus.groovy.ast.GroovyCodeVisitor;

/**
 * Represents a constant value expression such as literals (null, true, false, numbers, strings),
 * class literals, and other compile-time constant values. Each user-defined constant expression
 * maintains its own instance to preserve line and column information for accurate error reporting.
 * Predefined instances (e.g., {@link #NULL}, {@link #TRUE}, {@link #FALSE}) are provided as
 * internal constants and should not be compared directly; use the {@code isXXXExpression()} methods instead.
 *
 * @see Expression
 * @see VariableExpression
 * @see BinaryExpression
 */
public class ConstantExpression extends Expression {
    /**
     * Shared null constant. A null literal from source has its own instance, so
     * identity comparison with this field is not a null test; use {@link #isNullExpression()}.
     */
    public static final ConstantExpression NULL = new ConstantExpression(null);
    /**
     * Shared {@link Boolean#TRUE} constant, typed as {@code Boolean}. A {@code true}
     * literal from source has its own instance; use {@link #isTrueExpression()}.
     */
    public static final ConstantExpression TRUE = new ConstantExpression(Boolean.TRUE);
    /**
     * Shared {@link Boolean#FALSE} constant, typed as {@code Boolean}. A {@code false}
     * literal from source has its own instance; use {@link #isFalseExpression()}.
     */
    public static final ConstantExpression FALSE = new ConstantExpression(Boolean.FALSE);
    /**
     * Shared empty-string constant. An empty string literal from source has its own
     * instance; use {@link #isEmptyStringExpression()}.
     */
    public static final ConstantExpression EMPTY_STRING = new ConstantExpression("");
    /**
     * {@link Boolean#TRUE} with the primitive type kept, so the expression type is
     * {@code boolean} rather than {@code Boolean}.
     */
    public static final ConstantExpression PRIM_TRUE = new ConstantExpression(Boolean.TRUE, true);
    /**
     * {@link Boolean#FALSE} with the primitive type kept, so the expression type is
     * {@code boolean} rather than {@code Boolean}.
     */
    public static final ConstantExpression PRIM_FALSE = new ConstantExpression(Boolean.FALSE, true);

    /**
     * Constant whose value is {@code Void.class}. Source code has no literal of this form.
     */
    public static final ConstantExpression VOID = new ConstantExpression(Void.class);
    /**
     * Null-valued placeholder for a missing size or initializer. Callers recognize
     * it by identity, unlike {@link #NULL}.
     */
    public static final ConstantExpression EMPTY_EXPRESSION = new ConstantExpression(null);

    private final Object value;
    private String constantName;

    /**
     * Creates a constant expression with the specified value. The type of this constant
     * expression will be inferred from the value's class.
     *
     * @param value the constant value; may be null to represent a null literal
     */
    public ConstantExpression(Object value) {
        this(value, false);
    }

    /**
     * Creates a constant expression with optional primitive type preservation.
     * If {@code keepPrimitive} is true, primitive wrapper types (Integer, Long, Boolean, etc.)
     * are kept as their primitive equivalents rather than boxed types.
     *
     * @param value the constant value; may be null
     * @param keepPrimitive if true, preserve primitive types for wrapper classes (e.g., Integer
     *                      becomes int); if false, use the boxed type
     */
    public ConstantExpression(Object value, boolean keepPrimitive) {
        this.value = value;
        if (value != null) {
            if (keepPrimitive) {
                if (value instanceof Integer) {
                    setType(ClassHelper.int_TYPE);
                } else if (value instanceof Long) {
                    setType(ClassHelper.long_TYPE);
                } else if (value instanceof Boolean) {
                    setType(ClassHelper.boolean_TYPE);
                } else if (value instanceof Double) {
                    setType(ClassHelper.double_TYPE);
                } else if (value instanceof Float) {
                    setType(ClassHelper.float_TYPE);
                } else if (value instanceof Character) {
                    setType(ClassHelper.char_TYPE);
                } else {
                    setType(ClassHelper.make(value.getClass()));
                }
                //TODO: more cases here
            } else {
                setType(ClassHelper.make(value.getClass()));
            }
        }
    }

    @Override
    public String toString() {
        return super.toString() + "[" + value + "]";
    }

    @Override
    public void visit(GroovyCodeVisitor visitor) {
        visitor.visitConstantExpression(this);
    }

    @Override
    public Expression transformExpression(ExpressionTransformer transformer) {
        return this;
    }

    /**
     * Returns the constant value represented by this expression.
     *
     * @return the constant value; may be null to represent a null literal
     */
    public Object getValue() {
        return value;
    }

    @Override
    public String getText() {
        return (value == null ? "null" : value.toString());
    }

    /**
     * Returns the constant name associated with this expression. This is typically used for
     * named constants defined in source code.
     *
     * @return the constant name; may be null if not set
     */
    public String getConstantName() {
        return constantName;
    }

    /**
     * Sets the constant name for this expression.
     *
     * @param constantName the name to associate with this constant; may be null
     */
    public void setConstantName(String constantName) {
        this.constantName = constantName;
    }

    /**
     * Indicates whether this constant expression represents a null value.
     *
     * @return true if this expression represents null; false otherwise
     */
    public boolean isNullExpression() {
        return value == null;
    }

    /**
     * Indicates whether this constant expression represents the boolean true value.
     *
     * @return true if this expression represents Boolean.TRUE; false otherwise
     */
    public boolean isTrueExpression() {
        return Boolean.TRUE.equals(value);
    }

    /**
     * Indicates whether this constant expression represents the boolean false value.
     *
     * @return true if this expression represents Boolean.FALSE; false otherwise
     */
    public boolean isFalseExpression() {
        return Boolean.FALSE.equals(value);
    }

    /**
     * Indicates whether this constant expression represents an empty string value.
     *
     * @return true if this expression represents an empty string; false otherwise
     */
    public boolean isEmptyStringExpression() {
        return "".equals(value);
    }
}
