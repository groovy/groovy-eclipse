/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.lang;

import org.codehaus.groovy.runtime.InvokerHelper;

import java.beans.Transient;

/**
 * Base class for Java objects wishing to be Groovy objects.
 */
public abstract class GroovyObjectSupport implements GroovyObject {

    // never persist the MetaClass
    private transient MetaClass metaClass = getDefaultMetaClass();

    /** {@inheritDoc} */
    @Override
    @Transient
    public MetaClass getMetaClass() {
        return this.metaClass;
    }

    /** {@inheritDoc} */
    @Override
    public void setMetaClass(/*@Nullable*/ final MetaClass metaClass) {
        this.metaClass = metaClass != null ? metaClass : getDefaultMetaClass();
    }

    private MetaClass getDefaultMetaClass() {
        return InvokerHelper.getMetaClass(this.getClass());
    }
}
