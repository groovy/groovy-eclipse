/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.lang;

import java.io.Serial;

/**
 * An exception thrown by a closure invocation
 */
public class ClosureException extends RuntimeException {

    @Serial private static final long serialVersionUID = -945565055750688719L;
    private final Closure closure;

    /**
     * Creates a new closure exception.
     *
     * @param closure the closure that failed
     * @param cause the underlying cause
     */
    public ClosureException(Closure closure, Throwable cause) {
        super("Exception thrown by call to closure: " + closure + " reason: " + cause, cause);
        this.closure = closure;
    }

    /**
     * Returns the closure that threw the exception.
     *
     * @return the failing closure
     */
    public Closure getClosure() {
        return closure;
    }
}
