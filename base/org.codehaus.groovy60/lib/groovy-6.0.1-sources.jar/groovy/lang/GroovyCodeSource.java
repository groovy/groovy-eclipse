/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.lang;

import groovy.security.GroovyCodeSourcePermission;
import groovy.util.CharsetToolkit;
import org.codehaus.groovy.runtime.IOGroovyMethods;
import org.codehaus.groovy.runtime.ResourceGroovyMethods;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.security.CodeSource;
import java.security.cert.Certificate;
import java.util.Objects;

/**
 * CodeSource wrapper class that allows specific security policies to be associated with a class
 * compiled from groovy source.
 */
public class GroovyCodeSource {

    /**
     * The codeSource to be given the generated class.  This can be used by policy file
     * grants to administer security.
     */
    private CodeSource codeSource;

    /**
     * The name given to the generated class
     */
    private String name;

    /**
     * The groovy source to be compiled and turned into a class
     */
    private String scriptText;

    /**
     * The certificates used to sign the items from the codesource
     */
    Certificate[] certs;

    private boolean cachable;

    /**
     * True when {@link #name} was chosen by Groovy for this compilation.
     * A caller-supplied name leaves this unset.
     */
    private boolean nameGenerated;

    private File file;

    private URL url;

    /**
     * Creates a code source from script text with an explicit logical name and code base.
     *
     * @param script the Groovy source text
     * @param name the logical script name
     * @param codeBase the code base used to create the backing {@link CodeSource}
     */
    public GroovyCodeSource(String script, String name, String codeBase) {
        this.name = name;
        this.scriptText = script;
        this.codeSource = createCodeSource(codeBase);
        this.cachable = true;
    }

    /**
     * Construct a GroovyCodeSource for an inputStream of groovyCode that has an
     * unknown provenance -- meaning it didn't come from a File or a URL (e.g.&#160;a String).
     * The supplied codeBase will be used to construct a File URL that should match up
     * with a java Policy entry that determines the grants to be associated with the
     * class that will be built from the InputStream.
     * <p>
     * The permission groovy.security.GroovyCodeSourcePermission will be used to determine if the given codeBase
     * may be specified.  That is, the current Policy set must have a GroovyCodeSourcePermission that implies
     * the codeBase, or an exception will be thrown.  This is to prevent callers from hijacking
     * existing codeBase policy entries unless explicitly authorized by the user.
     */
    public GroovyCodeSource(Reader reader, String name, String codeBase) {
        this.name = name;
        this.codeSource = createCodeSource(codeBase);

        try {
            this.scriptText = IOGroovyMethods.getText(reader);
        } catch (IOException e) {
            throw new RuntimeException("Impossible to read the text content from that reader, for script: " + name + " with codeBase: " + codeBase, e);
        }
    }

    /**
     * Creates a code source from a Groovy source file.
     *
     * @param infile the source file
     * @param encoding the character encoding used to read the file, or {@code null} for the default handling
     * @throws IOException if the file cannot be read
     */
    public GroovyCodeSource(final File infile, final String encoding) throws IOException {
        // avoid files which confuse us like ones with .. in path
        final File file = new File(infile.getCanonicalPath());
        if (!file.exists()) {
            throw new FileNotFoundException(file.toString() + " (" + file.getAbsolutePath() + ")");
        }
        if (file.isDirectory()) {
            throw new IllegalArgumentException(file.toString() + " (" + file.getAbsolutePath() + ") is a directory not a Groovy source file.");
        }
        try {
            if (!file.canRead())
                throw new RuntimeException(file.toString() + " can not be read. Check the read permission of the file \"" + file.toString() + "\" (" + file.getAbsolutePath() + ").");
        }
        catch (SecurityException e) {
            throw e;
        }

        this.file = file;
        this.cachable = true;
        //The calls below require access to user.dir - allow here since getName() and getCodeSource() are
        //package private and used only by the GroovyClassLoader.
        try {
            // retrieve the content of the file using the provided encoding
            if (encoding != null) {
                scriptText = ResourceGroovyMethods.getText(infile, encoding);
            } else {
                scriptText = ResourceGroovyMethods.getText(infile);
            }

            Object[] info = new Object[2];
            URL url = file.toURI().toURL();
            info[0] = url.toExternalForm();
            //toURI().toURL() will encode, but toURL() will not.
            info[1] = new CodeSource(url, (Certificate[]) null);

            this.name = (String) info[0];
            this.codeSource = (CodeSource) info[1];
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Could not construct CodeSource for file: " + file, e);
        }
    }

    /**
     * @param infile the file to create a GroovyCodeSource for.
     * @throws IOException if an issue arises opening and reading the file.
     */
    public GroovyCodeSource(final File infile) throws IOException {
        this(infile, CharsetToolkit.getDefaultSystemCharset().name());
    }

    /**
     * Creates a code source from the Groovy source available at the supplied URI.
     *
     * @param uri the source URI
     * @throws IOException if the source cannot be read
     */
    public GroovyCodeSource(URI uri) throws IOException {
        this(uri.toURL());
    }

    /**
     * Creates a code source from the Groovy source available at the supplied URL.
     *
     * @param url the source URL
     */
    public GroovyCodeSource(URL url) {
        if (url == null) {
            throw new RuntimeException("Could not construct a GroovyCodeSource from a null URL");
        }
        this.url = url;
        // TODO: GROOVY-6561: GroovyMain got the name this way: script.substring(script.lastIndexOf('/') + 1)
        this.name = url.toExternalForm();
        this.codeSource = new CodeSource(url, (Certificate[]) null);
        try {
            String contentEncoding = getContentEncoding(url);
            if (contentEncoding != null) {
                this.scriptText = ResourceGroovyMethods.getText(url, contentEncoding);
            } else {
                this.scriptText = ResourceGroovyMethods.getText(url); // falls-back on default encoding
            }
        } catch (IOException e) {
            throw new RuntimeException("Impossible to read the text content from " + name, e);
        }
    }

    /**
     * TODO(jwagenleitner): remove or fix in future release
     *
     * According to the spec getContentEncoding() returns the Content-Encoding
     * HTTP Header which typically carries values such as 'gzip' or 'deflate'
     * and is not the character set encoding. For compatibility in 2.4.x,
     * this behavior is retained but should be removed or fixed (parse
     * charset from Content-Type header) in future releases.
     *
     * see GROOVY-8056 and https://github.com/apache/groovy/pull/500
     */
    private static String getContentEncoding(URL url) throws IOException {
        URLConnection urlConnection = url.openConnection();
        String encoding = urlConnection.getContentEncoding();
        try {
            IOGroovyMethods.closeQuietly(urlConnection.getInputStream());
        } catch (IOException ignore) {
            // For compatibility, ignore exceptions from getInputStream() call
        }
        return encoding;
    }

    /**
     * Returns the {@link CodeSource} associated with compiled script classes.
     *
     * @return the code source for this script
     */
    public CodeSource getCodeSource() {
        return codeSource;
    }

    /**
     * Returns the Groovy source text.
     *
     * @return the script text
     */
    public String getScriptText() {
        return scriptText;
    }

    /**
     * Returns the logical name used for the script.
     *
     * @return the script name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the backing file when this code source was created from a file.
     *
     * @return the backing file, or {@code null} if this source does not originate from a file
     */
    public File getFile() {
        return file;
    }

    /**
     * Returns the backing URL when this code source was created from a URL.
     *
     * @return the backing URL, or {@code null} if this source does not originate from a URL
     */
    public URL getURL() {
        return url;
    }

    /**
     * Controls whether classes compiled from this source may be cached by {@link GroovyClassLoader}.
     *
     * @param b {@code true} to allow caching, {@code false} otherwise
     */
    public void setCachable(boolean b) {
        cachable = b;
    }

    /**
     * Indicates whether classes compiled from this source may be cached.
     *
     * @return {@code true} if the source is cacheable
     */
    public boolean isCachable() {
        return cachable;
    }

    /**
     * Marking a name as generated disables the custom MetaClass lookup and the
     * immediate BeanInfo lookup for that class and its nested classes, and
     * answers the {@code Customizer} probe without delegation.
     *
     * @param generated {@code true} when Groovy minted the name
     * @since 6.0.1
     */
    public void setNameGenerated(boolean generated) {
        nameGenerated = generated;
    }

    /**
     * Indicates whether {@link #getName()} was chosen by Groovy.
     *
     * @return {@code true} when the name was generated for this source
     * @since 6.0.1
     */
    public boolean isNameGenerated() {
        return nameGenerated;
    }

    @SuppressWarnings("removal") // TODO a future Groovy version should remove the security check
    private static CodeSource createCodeSource(final String codeBase) {
        SecurityManager sm = System.getSecurityManager();
        if (sm != null) {
            sm.checkPermission(new GroovyCodeSourcePermission(codeBase));
        }
        try {
            String path = codeBase.startsWith("/") ? codeBase : "/" + codeBase;
            return new CodeSource(new URI("file", "", path, null).toURL(), (Certificate[]) null);
        }
        catch (MalformedURLException | URISyntaxException e) {
            throw new RuntimeException("A CodeSource file URL cannot be constructed from the supplied codeBase: " + codeBase);
        }
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroovyCodeSource that = (GroovyCodeSource) o;
        return Objects.equals(codeSource, that.codeSource);
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return Objects.hash(codeSource);
    }
}
