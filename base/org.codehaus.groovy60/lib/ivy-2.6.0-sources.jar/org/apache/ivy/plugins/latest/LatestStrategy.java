/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.ivy.plugins.latest;

import java.util.Date;
import java.util.List;

public interface LatestStrategy {
    /**
     * Finds the latest artifact among the given artifacts info. The definition of 'latest' depends
     * on the strategy itself. Given artifacts info are all good candidate. If the given date is not
     * null, then found artifact should not be later than this date.
     *
     * @param infos ArtifactInfo[]
     * @param date Date
     * @return the latest artifact among the given ones.
     */
    ArtifactInfo findLatest(ArtifactInfo[] infos, Date date);

    /**
     * Sorts the given artifacts info from the oldest one to the latest one. The definition of
     * 'latest' depends on the strategy itself. Given artifacts info are all good candidate.
     *
     * @param infos ArtifactInfo[]
     * @return List&lt;ArtifactInfo&gt;
     */
    List<ArtifactInfo> sort(ArtifactInfo[] infos);

    String getName();
}
