/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.ivy.plugins.resolver.util;

import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.apache.ivy.util.url.ApacheURLLister;

public class ApacheHttpURLLister implements URLLister {
    private ApacheURLLister lister = new ApacheURLLister();

    public boolean accept(String pattern) {
        return pattern.startsWith("http");
    }

    public List<URL> listAll(URL url) throws IOException {
        return lister.listAll(url);
    }

    @Override
    public String toString() {
        return "apache http lister";
    }
}
