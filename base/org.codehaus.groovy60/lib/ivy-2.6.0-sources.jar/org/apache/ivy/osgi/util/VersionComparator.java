/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.ivy.osgi.util;

import java.util.Comparator;

public class VersionComparator implements Comparator<Version> {

    public static final Comparator<Version> ASCENDING = new VersionComparator(false);

    public static final Comparator<Version> DESCENDING = new VersionComparator(true);

    public final boolean reverse;

    private VersionComparator(boolean reverse) {
        this.reverse = reverse;
    }

    public int compare(Version objA, Version objB) {
        final int val = objA.compareTo(objB);
        return reverse ? -val : val;
    }

}
