
TemplateServlet examples

[ /readme.txt ]
This readme file. For clarity sake, it does not contain a welcome file and
therefore the servlet container should list all files and subdirectories listed
below.

[ /3.times.HelloWorld.html ]
Prints three times "Hello World!" and the session id.

[ /javasystemproperties.htm ]
Lists Java runtime system properties.
